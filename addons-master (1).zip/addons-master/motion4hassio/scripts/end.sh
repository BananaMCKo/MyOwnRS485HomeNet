#!/bin/sh

#$PWD/sendTelegram.sh "Motion End"
echo "[Info] Motion End"

