#!/bin/sh

#$PWD/sendTelegram.sh "Motion Start"
echo "[Info] Motion Start"

