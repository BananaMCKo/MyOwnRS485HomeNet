#!/bin/sh

#$PWD/sendTelegram.sh "MOVIE End"
#$PWD/sendFile.sh $1
echo "[Info] Movie Ended"
