# OwntracksREC

## About ver 0.7.1
Owntracks Recorder Addon for Hassio

## Configuration

config:
```yaml
	localHost: 0.0.0.0
	mqttServer: core-mosquitto
	mqttPort: 1883
	mqttUser: username
	mqttPassword: password
```
### Option `mqttUser` (required)

### Option `mqttPassword` (required)

